# Akbatı Sesli Sıra Takip

Bu Android proje, erişilebilirlik hizmeti üzerinden ekrandaki `x/16` sayacını algılamayı ve ilk sayıyı Türkçe TTS ile anons etmeyi dener.

## Önemli test notu
Bu ilk sürüm, sıra uygulamasının sayacı Android erişilebilirlik ağacında metin olarak sunmasına bağlıdır. Sayaç yalnızca resim/canvas olarak çiziliyorsa bu yöntem okuyamaz; OCR/ekran yakalama tabanlı ayrı bir sürüm gerekir.

## Derleme
Android Studio ile açın ve `app` için debug APK oluşturun. GitHub Actions iş akışı da `.github/workflows/android.yml` üzerinden APK üretir.

## Kullanım
Uygulamayı açın, "Erişilebilirlik ayarlarını aç" düğmesine basın ve "Akbatı Sıra Takip" hizmetini etkinleştirin. Sonra sıra ekranına dönün. İlk bulunan `x/16` değeri değiştiğinde yalnızca değişen ilk sayı anons edilir.
