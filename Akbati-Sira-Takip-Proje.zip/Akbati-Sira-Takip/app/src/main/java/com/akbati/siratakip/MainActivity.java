package com.akbati.siratakip;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Akbatı Sesli Sıra Takip");
        title.setTextSize(24);
        title.setPadding(0, 0, 0, 24);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("Sarı kutudaki 5/16 sayacının ilk sayısı değiştiğinde Türkçe sesle anons eder.\n\nKullanmak için aşağıdaki düğmeye basıp Akbatı Sıra Takip erişilebilirlik hizmetini açın.");
        info.setTextSize(16);
        info.setPadding(0, 0, 0, 24);
        layout.addView(info);

        Button button = new Button(this);
        button.setText("Erişilebilirlik ayarlarını aç");
        button.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        layout.addView(button);

        TextView note = new TextView(this);
        note.setText("\nNot: Sıra uygulaması ekrandaki sayacı erişilebilir metin olarak sunmuyorsa otomatik okuma çalışmayabilir. Önce cihazda test edeceğiz.");
        note.setTextSize(14);
        note.setPadding(0, 24, 0, 0);
        layout.addView(note);

        setContentView(layout);
    }
}
