package com.akbati.siratakip;

import android.accessibilityservice.AccessibilityService;
import android.speech.tts.TextToSpeech;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueueAccessibilityService extends AccessibilityService {
    private TextToSpeech tts;
    private boolean ready = false;
    private String lastAnnounced = "";
    private long lastAnnouncementTime = 0;
    private static final Pattern COUNTER = Pattern.compile("(?<!\\d)(\\d{1,2})\\s*/\\s*16(?!\\d)");

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("tr", "TR"));
                ready = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || !ready) return;
        StringBuilder text = new StringBuilder();
        if (event.getText() != null) {
            for (CharSequence item : event.getText()) {
                if (item != null) text.append(item).append(' ');
            }
        }
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            collectText(root, text, 0);
            root.recycle();
        }
        Matcher matcher = COUNTER.matcher(text.toString());
        if (matcher.find()) {
            String number = matcher.group(1);
            long now = System.currentTimeMillis();
            if (!number.equals(lastAnnounced) && now - lastAnnouncementTime > 1200) {
                lastAnnounced = number;
                lastAnnouncementTime = now;
                tts.speak(number, TextToSpeech.QUEUE_FLUSH, null, "queue-" + number);
            }
        }
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder out, int depth) {
        if (node == null || depth > 20) return;
        CharSequence t = node.getText();
        CharSequence d = node.getContentDescription();
        if (t != null) out.append(t).append(' ');
        if (d != null) out.append(d).append(' ');
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectText(child, out, depth + 1);
                child.recycle();
            }
        }
    }

    @Override public void onInterrupt() { }

    @Override public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
