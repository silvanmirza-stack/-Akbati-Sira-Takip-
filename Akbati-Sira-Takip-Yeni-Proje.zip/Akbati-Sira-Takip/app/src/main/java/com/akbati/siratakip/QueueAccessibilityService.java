package com.akbati.siratakip;

import android.accessibilityservice.AccessibilityService;
import android.speech.tts.TextToSpeech;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class QueueAccessibilityService extends AccessibilityService {
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private String lastAnnounced = "";

    private static final Pattern COUNTER =
        Pattern.compile("(?<!\\d)(\\d{1,2})\\s*/\\s*16(?!\\d)");

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                int result = tts.setLanguage(new Locale("tr", "TR"));
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA
                        && result != TextToSpeech.LANG_NOT_SUPPORTED;
            }
        });
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;
        StringBuilder text = new StringBuilder();

        for (CharSequence item : event.getText()) {
            if (item != null) text.append(item).append(' ');
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root != null) {
            collectText(root, text);
            root.recycle();
        }

        Matcher matcher = COUNTER.matcher(text.toString());
        if (matcher.find()) {
            String number = matcher.group(1);
            if (!number.equals(lastAnnounced) && ttsReady && tts != null) {
                lastAnnounced = number;
                tts.speak(number, TextToSpeech.QUEUE_FLUSH, null, "queue-" + number);
            }
        }
    }

    private void collectText(AccessibilityNodeInfo node, StringBuilder out) {
        if (node == null) return;
        CharSequence value = node.getText();
        if (value != null) out.append(value).append(' ');
        CharSequence description = node.getContentDescription();
        if (description != null) out.append(description).append(' ');

        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                collectText(child, out);
                child.recycle();
            }
        }
    }

    @Override
    public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
