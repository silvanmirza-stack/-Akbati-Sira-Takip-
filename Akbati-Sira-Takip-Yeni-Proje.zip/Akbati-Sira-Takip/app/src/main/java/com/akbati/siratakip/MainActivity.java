package com.akbati.siratakip;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(32, 48, 32, 32);
        layout.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("Akbatı Sesli Sıra Takip");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        layout.addView(title);

        TextView info = new TextView(this);
        info.setText("Sarı sayaçtaki 1/16, 2/16 gibi sıra numarasını değiştiğinde sesli duyurur.\n\nÇalışması için aşağıdaki düğmeden Erişilebilirlik ayarlarını açıp 'Akbatı Sıra Seslendirme' hizmetini etkinleştirin.\n\nNot: Sayaç uygulama tarafından erişilebilir metin olarak sunulmuyorsa bu yöntem sayıyı okuyamayabilir.");
        info.setTextSize(16);
        info.setPadding(0, 32, 0, 32);
        layout.addView(info);

        Button settings = new Button(this);
        settings.setText("Erişilebilirlik ayarlarını aç");
        settings.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        );
        layout.addView(settings);

        setContentView(layout);
    }
}
